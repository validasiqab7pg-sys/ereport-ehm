<?php

namespace App\Models;
use CodeIgniter\Model;
// use Modules\Authentication\Models\UserAuthModel;

class PpojModel extends Model
{
    protected $table = 'data_awal_ppoj';
    protected $primaryKey = 'id';
    protected $returnType = 'array';
    //protected $useSoftDeletes = 'true';
    protected $allowedFields = ['id','no_ppoj','ahu','tanggaldilakukan','site','nama_ruangan','kelas','kondisi','status','jenispemeriksaan','id_ahu','jumlah_pertukaran_udara'
    ];
   

     public function List_Detail_Suhu($id = null)
    {
       
      
     $query = $this->db->query('SELECT DISTINCT A.*,B.status as status_suhu FROM data_awal_ppoj A LEFT JOIN suhu B ON A.id = B.id_ppoj WHERE A.id_ahu AND A.id_ahu ='.$id.'');

      $data = $query->getResultArray();
      return $data; 
    
    }
    
    public function countSelesaiSuhu($id = null)
    {
       
      
     $query = $this->db->query('SELECT count(*) selesaiSuhu FROM data_awal_ppoj A LEFT JOIN suhu B ON A.id = B.id_ppoj WHERE A.id_ahu AND B.status is null AND A.id_ahu ='.$id.'');

      $data = $query->getResultArray();
      return $data; 
    
    }
    
     public function List_Detail_Lux($id = null)
    {
       
      
     $query = $this->db->query('SELECT DISTINCT A.*,B.status as status_lux FROM data_awal_ppoj A LEFT JOIN lux B ON A.id = B.id_ppoj WHERE A.id_ahu AND A.id_ahu ='.$id.'');

      $data = $query->getResultArray();
      return $data; 
    
    }
      public function countSelesaiLux($id = null)
    {
       
      
     $query = $this->db->query('SELECT count(*) selesaiLux FROM data_awal_ppoj A LEFT JOIN lux B ON A.id = B.id_ppoj WHERE A.id_ahu AND B.status is null AND A.id_ahu ='.$id.'');

      $data = $query->getResultArray();
      return $data; 
    }
    
     public function List_Detail_Flow($id = null)
    {
       
      
     $query = $this->db->query('SELECT DISTINCT A.*,B.status as status_flow FROM data_awal_ppoj A LEFT JOIN flow  B ON A.id = B.id_ppoj WHERE A.id_ahu AND A.id_ahu ='.$id.'');

      $data = $query->getResultArray();
      return $data; 
    
    }
    
    public function countSelesaiFlow($id = null)
    {
       
      
     $query = $this->db->query('SELECT count(*) selesaiFlow FROM data_awal_ppoj A LEFT JOIN flow B ON A.id = B.id_ppoj WHERE A.id_ahu AND B.status is null AND A.id_ahu ='.$id.'');

      $data = $query->getResultArray();
      return $data; 
    }
    
    public function List_Detail_Rh($id = null)
    {
       
      
     $query = $this->db->query('SELECT DISTINCT A.*,B.status as status_rh FROM data_awal_ppoj A LEFT JOIN rh B ON A.id = B.id_ppoj WHERE A.id_ahu AND A.id_ahu ='.$id.'');

      $data = $query->getResultArray();
      return $data; 
    
    }
       public function countSelesaiRh($id = null)
    {
       
      
     $query = $this->db->query('SELECT count(*) selesaiRh FROM data_awal_ppoj A LEFT JOIN rh B ON A.id = B.id_ppoj WHERE A.id_ahu AND B.status is null AND A.id_ahu ='.$id.'');

      $data = $query->getResultArray();
      return $data; 
    
    }
    
    public function List_Detail_Dp($id = null)
    {
       
      
     $query = $this->db->query('SELECT DISTINCT A.*,B.status as status_dp FROM data_awal_ppoj A LEFT JOIN dp B ON A.id = B.id_ppoj WHERE A.id_ahu AND A.id_ahu ='.$id.'');

      $data = $query->getResultArray();
      return $data; 
    
    }
     public function countSelesaiDp($id = null)
    {
       
      
     $query = $this->db->query('SELECT count(*) selesaiDp FROM data_awal_ppoj A LEFT JOIN dp B ON A.id = B.id_ppoj WHERE A.id_ahu AND B.status is null AND A.id_ahu ='.$id.'');

      $data = $query->getResultArray();
      return $data; 
    
    }
     public function List_Detail_Mas($id = null)
    {
       
      
     $query = $this->db->query('SELECT DISTINCT A.*,B.status as status_mas FROM data_awal_ppoj A LEFT JOIN mikro_volumetrik B ON A.id = B.id_ppoj WHERE A.id_ahu AND A.id_ahu ='.$id.'');

      $data = $query->getResultArray();
      return $data; 
    
    }
    
     public function List_Detail_Capar($id = null)
    {
       
      
     $query = $this->db->query('SELECT DISTINCT A.*,B.status as status_capar FROM data_awal_ppoj A LEFT JOIN mikro_capar B ON A.id = B.id_ppoj WHERE A.id_ahu   ='.$id.'');

      $data = $query->getResultArray();
      return $data; 
    
    }
    
    public function List_Detail_Patogen($id = null)
    {
       
      
     $query = $this->db->query('SELECT A.*,B.status as status_patogen FROM data_awal_ppoj A LEFT JOIN patogen B ON A.id = B.id_ppoj WHERE A.id_ahu AND A.id_ahu ='.$id.'');

      $data = $query->getResultArray();
      return $data; 
    
    }
    public function Cek_button_qa($id = null)
    {
       
      
     $query = $this->db->query('SELECT COUNT(*) as totalSelesai FROM `data_ahu` WHERE id = '.$id.' AND statusRH =1 AND statusDP =1 AND statusSuhu =1 AND statusFlow =1 AND  statusLux=1');

      $data = $query->getResultArray();
      return $data; 
    
    }
    
      public function Cek_button_qc($id = null)
    {
       
      
     $query = $this->db->query('SELECT COUNT(*) as totalSelesai FROM `data_ahu` WHERE id = '.$id.' AND  statusMas =1 AND statusCapar =1 AND  statusPatogen=1');

      $data = $query->getResultArray();
      return $data; 
    
    }
      public function cekKeterangan($id = null)
    {
       
      
     $query = $this->db->query('SELECT COUNT(*) as cekKondisi
    FROM
    	suhu A,rh B,dp C,flow D,mikro_volumetrik E,mikro_capar F
     WHERE 
    A.id_ppoj = '.$id.' and 
    A.id_ppoj = B.id_ppoj  and 
    A.id_ppoj = C.id_ppoj  and 
    A.id_ppoj = D.id_ppoj and 
	A.id_ppoj = E.id_ppoj and 
	A.id_ppoj = F.id_ppoj and 
    A.keterangan = B.keterangan AND 
    A.keterangan = C.keterangan AND 
    A.keterangan = D.keterangan AND 
    A.keterangan = E.keterangan AND 
    A.keterangan = F.keterangan');

      $data = $query->getResultArray();
      return $data; 
    
    }
    public function List_PPOJ_AHU()
    {
      $session = session();
    
    //   $builder = $this->db->table("data_awal_ppoj");
    //   $builder->distinct('ahu,tanggaldilakukan');
     //$builder->select('id,ahu,tanggaldilakukan,jenispemeriksaan,kondisi,site,status');
      
     $query = $this->db->query('SELECT * FROM data_awal_ppoj GROUP by ahu,tanggaldilakukan;');

      $data = $query->getResultArray();
      return $data; 
    
    }

    public function List_SUHU()
    {
      $session = session();
    
     $query = $this->db->query('SELECT A.*,count(B.id_ahu) C_Ruangan FROM data_ahu A, `data_awal_ppoj` B WHERE A.id =B.id_ahu GROUP BY B.id_ahu;');

      $data = $query->getResultArray();
      return $data; 
    
    }
    public  function QuerySuhu()
    {
      return '(select 
      ID_PPOJ, 
      ROW_NUMBER() over (partition by ID_PPOJ order by SUHU_MIN) as rn, 
      SUHU_MIN, 
      SUHU_MAX 
    from 
      suhu )';
    }
    public function QueryRh()
    {
      return' ( select 
      ID_PPOJ, 
      ROW_NUMBER() over (partition by ID_PPOJ order by RH_MIN) as rn, 
      RH_MIN, 
      RH_MAX 
    from rh )';
    }
    public function QueryCapar()
    {
      return '( select 
      ID_PPOJ, 
      ROW_NUMBER() over (partition by ID_PPOJ order by HASIL_TPC) as rn, 
      HASIL_TPC, 
      HASIL_KK 
    from mikro_capar )';
    }
    public function QueryMas()
    {
      return '( select 
      ID_PPOJ, 
      ROW_NUMBER() over (partition by ID_PPOJ order by HASIL_TPC) as rn, 
      HASIL_TPC, 
      HASIL_KK 
    from mikro_volumetrik )';
    }
    public function DataPDF($suhu,$rh,$capar,$mas,$id)
    {
      $query = '';

      //-------------------------------------------------- Jika Suhu terbesar
      if($suhu >= $rh && $suhu >= $capar && $suhu >= $mas)
      {
        $query1 = $this->QuerySuhu();
        $q1 = 't1';
        if( $rh >= $capar && $rh >= $mas)
        {
          
          $query2 = $this->QueryRh();
          $q2 = 't2';
          if( $capar >= $mas)
          {
            $query3 = $this->QueryCapar();
            $query4 = $this->QueryMas();
            $q3 = 't3';
            $q4 = 't4';
          }
          else if( $mas >= $capar)
          {
            $query3 = $this->QueryMas();
            $query4 = $this->QueryCapar();
            $q3 = 't4';
            $q4 = 't3';
          }
        }
        else if( $capar >= $rh && $capar >= $mas)
        {
          $query2 = $this->QueryCapar();
          $q2 = 't3';
          if( $rh >= $mas)
          {
            $query3 = $this->QueryRh();
            $query4 = $this->QueryMas();
            $q3 = 't2';
            $q4 = 't4';
          }
          else if( $mas >= $rh)
          {
            $query3 =  $this->QueryMas();
            $query4 = $this->QueryRh();
            $q3 = 't4';
            $q4 = 't2';

          }
        }
        else if( $mas >= $rh && $mas >= $capar)
        {
          $query2 = $this->QueryMas();
          $q2 = 't4';
          if( $rh >= $capar)
          {
            $query3 =  $this->QueryRh();
            $query4 = $this->QueryCapar();
            $q3 = 't2';
            $q4 = 't3';
          }
          else if( $capar >= $rh)
          {
            $query3 =  $this->QueryCapar();
            $query4 = $this->QueryRh();
            $q3 = 't3';
            $q4 = 't2';
          }
          
        }
       
      }
//-------------------------------------------------- Jika RH terbesar
      else if($rh >= $suhu && $rh >= $capar && $rh >= $mas)
      {
        $query1 =  $this->QueryRh();
        $q1 = 't2';
        if( $suhu >= $capar && $suhu >= $mas)
        {
          $query2 =  $this->QuerySuhu();
          $q2 = 't1';
          if( $capar >= $mas)
          {
            $query3 =  $this->QueryCapar();
            $query4 =  $this->QueryMas();
            $q3 = 't3';
            $q4 = 't4';
          }
          else if( $mas >= $capar)
          {
            $query3 =  $this->QueryMas();
            $query4 =  $this->QueryCapar();
            $q3 = 't4';
            $q4 = 't3';
          }
        }
        else if( $capar >= $suhu && $capar >= $mas)
        {
          $query2 =  $this->QueryCapar();
          $q2 = 't2';
          if( $suhu >= $mas)
          {
            $query3 =  $this->QuerySuhu();
            $query4 =  $this->QueryCapar();
            $q3 = 't1';
            $q4 = 't3';
          }
          else if( $mas >= $suhu)
          {
            $query3 =  $this->QueryMas();
            $query4 =  $this->QuerySuhu();
            $q3 = 't4';
            $q4 = 't1';
          }
          
        }
        else if( $mas >= $suhu && $mas >= $capar)
        {
          $query2 =  $this->QueryMas();
          $q2 = 't4';
          if( $suhu >= $capar)
          {
            $query3 =  $this->QuerySuhu();
            $query4 =  $this->QueryCapar();
            $q3 = 't1';
            $q4 = 't3';
          }
          else if( $capar >= $suhu)
          {
            $query3 =  $this->QueryCapar();
            $query4 =  $this->QuerySuhu();
            $q3 = 't3';
            $q4 = 't1';
          }
        }
      }
    
       //-------------------------------------------------- Jika Capar terbesar
       else if($capar >= $suhu && $capar >= $rh && $capar >= $mas)
       {
        $query1 =  $this->QueryCapar();
        $q1 = 't3';
         if( $suhu >= $rh && $suhu >= $mas)
         {
          $query2 =  $this->QuerySuhu();
          $q2 = 't1';
           if( $rh >= $mas)
           {
            $query3 =  $this->QueryRh();
            $query4 =  $this->QueryMas();
            $q3 = 't2';
            $q4 = 't4';
           }
           else if( $mas >= $rh)
           {
            $query3 =  $this->QueryMas();
            $query4 =  $this->QueryRh();
            $q3 = 't4';
            $q4 = 't2';
           }
         }
         else if( $rh >= $suhu && $rh >= $mas)
         {
          $query2 =  $this->QueryRh();
          $q2 = 't2';
           if( $suhu >= $mas)
           {
            $query3 =  $this->QuerySuhu();
            $query4 =  $this->QueryMas();
            $q3 = 't1';
            $q4 = 't4';
           }
           else if( $mas >= $suhu)
           {
            $query3 =  $this->QueryMas();
            $query4 =  $this->QuerySuhu();
            $q3 = 't4';
            $q4 = 't1';
           }
           
         }
         else if( $mas >= $suhu && $mas >= $rh)
         {
          $query2 =  $this->QueryMas();
          $q2 = 't4';
           if( $suhu >= $rh)
           {
            $query3 =  $this->QuerySuhu();
            $query4 =  $this->QueryRh();
            $q3 = 't1';
            $q4 = 't2';
           }
           else if( $rh >= $suhu)
           {
            $query3 =  $this->QueryRh();
            $query4 =  $this->QuerySuhu();
            $q3 = 't2';
            $q4 = 't1';
           }
         }
       }
         //-------------------------------------------------- Jika Mas terbesar
      else if($mas >= $suhu && $mas >= $rh && $mas >= $capar)
      {
        $query1 =  $this->QueryMas();
        $q1 = 't4';
        if( $suhu >= $rh && $suhu >= $capar)
        {
          $query2 =  $this->QuerySuhu();
          $q2 = 't1';
          if( $rh >= $capar)
          {
            $query3 =  $this->QueryRh();
            $query4 =  $this->QueryCapar();
            $q3 = 't2';
            $q4 = 't3';
          }
          else if( $capar >= $rh)
          {
            $query3 =  $this->QueryCapar();
            $query4 =  $this->QueryRh();
            $q3 = 't3';
            $q4 = 't2';
          }
        }
        else if( $rh >= $suhu && $rh >= $capar)
        {
          $query2 =  $this->QueryRh();
          $q2 = 't2';
            
          if( $suhu >= $capar)
          {
            $query3 =  $this->QuerySuhu();
            $query4 =  $this->QueryCapar();
            $q3 = 't1';
            $q4 = 't3';
          }
          else if( $capar >= $suhu)
          {
            $query3 =  $this->QueryCapar();
            $query4 =  $this->QuerySuhu();
            $q3 = 't3';
            $q4 = 't1';
          }
          
        }
        else if( $capar >= $suhu && $capar >= $rh)
        {
          $query2 =  $this->QueryCapar();
          $q2 = 't3';
          if( $suhu >= $rh)
          {
            $query3 =  $this->QuerySuhu();
            $query4 =  $this->QueryRh();
            $q3 = 't1';
            $q4 = 't2';
          }
          else if( $rh >= $suhu)
          {
            $query3 =  $this->QueryRh();
            $query4 =  $this->QuerySuhu();
            $q3 = 't2';
            $q4 = 't1';
          }
        }
      }
//$query = $query1.''.$query2.''.$query3.''.$query4.''.$q1.''.$q2.''.$q3.''.$q4;
      return $this->DataSuhuRH($query1,$query2,$query3,$query4,$id,$q1,$q2,$q3,$q4);
     return $query;
    }
    public function DataSuhuRH($query1,$query2,$query3,$query4,$id,$q1,$q2,$q3,$q4)
    {
      $session = session();
    
     $query = $this->db->query
     (
        'SELECT 		 
        DAP.KELAS,
        DAP.ID ID_PPOJ,
        t1.SUHU_MIN, 
        t1.SUHU_MAX, 
        t2.RH_MIN, 
        t2.RH_MAX,
        t3.HASIL_TPC CAPAR_TPC,
        t3.HASIL_KK CAPAR_KK,
        t4.HASIL_TPC MIKRO_TPC,
        t4.HASIL_KK MIKRO_KK
    FROM 
    data_awal_ppoj DAP 
    LEFT JOIN 
    '.$query1.' '.$q1.' ON DAP.id = '.$q1.'.ID_PPOJ left join 
    '.$query2.' '.$q2.' on DAP.id = '.$q2.'.ID_PPOJ   and '.$q1.'.rn = '.$q2.'.rn LEFT join 
    '.$query3.' '.$q3.' ON DAP.id = '.$q3.'.id_ppoj AND '.$q2.'.rn = '.$q3.'.rn left JOIN
    '.$query4.' '.$q4.' ON DAP.id = '.$q4.'.id_ppoj AND '.$q3.'.rn = '.$q4.'.rn
      
      WHERE 
        DAP.id ='.$id.';
      '
     );

      $data = $query->getResultArray();
      return $data; 
    
    }
    public function List_RH()
    {
      $session = session();
    
    //   $builder = $this->db->table("data_awal_ppoj");
    //   $builder->distinct('ahu,tanggaldilakukan');
     //$builder->select('id,ahu,tanggaldilakukan,jenispemeriksaan,kondisi,site,status');
      
     $query = $this->db->query('SELECT A.*,count(B.id_ahu) C_Ruangan FROM data_ahu A, `data_awal_ppoj` B WHERE A.id =B.id_ahu GROUP BY B.id_ahu;');

      $data = $query->getResultArray();
      return $data; 
    
    }
    public function List_MAS()
    {
      $session = session();
    
    //   $builder = $this->db->table("data_awal_ppoj");
    //   $builder->distinct('ahu,tanggaldilakukan');
     //$builder->select('id,ahu,tanggaldilakukan,jenispemeriksaan,kondisi,site,status');
      
     $query = $this->db->query('SELECT A.*,count(B.id_ahu) C_Ruangan FROM data_ahu A, data_awal_ppoj B WHERE A.id =B.id_ahu and A.approve_1 != "" GROUP BY B.id_ahu  ');

      $data = $query->getResultArray();
      return $data; 
    
    }
    public function List_CAPAR()
    {
      $session = session();
    
      
     $query = $this->db->query('SELECT A.*,count(B.id_ahu) C_Ruangan FROM data_ahu A, `data_awal_ppoj` B WHERE A.id =B.id_ahu and A.approve_1 != "" GROUP BY B.id_ahu;');

      $data = $query->getResultArray();
      return $data; 
    
    }
      public function List_Patogen()
    {
      $session = session();
    
      
     $query = $this->db->query('SELECT A.*,count(B.id_ahu) C_Ruangan FROM data_ahu A, `data_awal_ppoj` B WHERE A.id =B.id_ahu and A.approve_1 != "" GROUP BY B.id_ahu;');

      $data = $query->getResultArray();
      return $data; 
    
    }
    public function Terhadap_Ruangan($id)
    {
      
     $query = $this->db->query('SELECT 
     terhadap_ruangan,hasil_dp FROM dp WHERE id_ppoj ='.$id.'');

      $data = $query->getResultArray();
      return $data; 
    
    }
    public function List_PPOJ_ID($id_ahu)
    {
      $session = session();
    
    //   $query = $this->db->query('SELECT * FROM data_awal_ppoj where id_ahu = '+$id_ahu+'');


          $builder = $this->db->table("data_awal_ppoj");
     $builder->select('*');
     $builder->where('id_ahu',$id_ahu);
      $data = $builder->get()->getResultArray();
      return $data; 

    
    }
    
}