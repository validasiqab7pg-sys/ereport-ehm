<?php

namespace App\Controllers;
use App\Models\UserModel;
class Auth extends BaseController
{
 
    public function Login()
    {
        return view('Login/login');
     
        //echo view('ListUser/index', $data);
    }

    public function Register()
    {
        return view('Login/register');
     
        //echo view('ListUser/index', $data);
    }
    public function Process_Login()
    {
        $session = session();
        $user = New UserModel;
        $getpost = $this->request->getPost();
        $finduser = $user->where('username',$getpost['username'])->where('password',$getpost['password'])->first();
      
        if($finduser)
        {
                 //if(password_verify('$', 'mia123')) 
          	//	if($finduser['password'],$getpost['password'])
         		// if(1==1)
                  
                    //jika benar, arahkan user masuk ke aplikasi 
                    $sessLogin = [
                        'isLogin' => true,
                        'username' => $finduser['username'],
                        'jabatan' => $finduser['jabatan']
                     

                    ];
                     $session->set($sessLogin);
                    return redirect()->to('/Home');
                
            } 
            else
            {
                
                session()->setFlashdata('Toast', 'Username atau Password Salah');
    		  return redirect()->to('/Auth/Login');
            }
        
        //return view('Login/register');
        
       // echo view('ListUser/index', $data);
    }
    public function Process_Register()
    {
        $session = session();
        $user = New UserModel;
        $getpost = $this->request->getPost();
       
        $user->insert([ 
            'username' => $getpost['username'],
            'password' => $getpost['password'],
            'email' => $getpost['email'],
            'department' => $getpost['department'],
            'jabatan' => $getpost['jabatan']
            //'password' => password_hash($this->request->getVar('password'), PASSWORD_BCRYPT)
           
        ]);
        $sessLogin = [
            'isLogin' => true,
            'username' => $getpost['username'],
            'jabatan' => $getpost['jabatan']
           
        ];
        $session->set($sessLogin);
        
         return redirect()->to('/');
    }
    public function Logout()
    {
        $session = session();
        $session->destroy();
        return redirect()->to('/');
    }
}
