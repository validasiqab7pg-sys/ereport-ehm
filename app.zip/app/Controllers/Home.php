<?php

namespace App\Controllers;
use App\Models\AllModel;
use App\Models\UserModel;
class Home extends BaseController
{
    public function index()//: string
    {
         return view('index');
       
    }
    public function Setting()
    {
        $modeluser = new UserModel();
        $session = session();
        $username = $session->get('username');
        $data = [
           
            'getdata' => $modeluser->where('username', $username)->first(),
            'judul' => 'Setting'

        ];

        //dd($data);
        echo view('Home/profile', $data);
    }
    public function UpdatePassword()
    {
        $modeluser = new UserModel();
        $getpost = $this->request->getPost();
        $id = $getpost['id'];
        $password = $getpost['password'];
        $newpassword = $getpost['newpassword'];
        $repassword = $getpost['repassword'];
        $user = $modeluser->where('id', $id)->first();
        //dd($user['PASSWORD']);
        if($user['password']==$password)
        {
           if($newpassword == $repassword)
           {
                $data = [
                            'password' => $getpost['newpassword'],
                        ];
                $modeluser->set($data)->where('id', $id);
                $modeluser->update();
                session()->setFlashdata('Toast', 'Password berhasil diubah');
                return redirect()->to('/Home');
           }
           else
           {
            session()->setFlashdata('repassword', 'Password baru dan password konfirmasi tidak cocok');
            return redirect()->to('/Home/Setting');
           }
        }
        else
        {
            session()->setFlashdata('password', 'Password salah');
            return redirect()->to('/Home/Setting');
        }
       
        
    }
}
