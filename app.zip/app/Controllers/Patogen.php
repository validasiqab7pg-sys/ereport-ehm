<?php
namespace App\Controllers;
use App\Models\AllModel;
use App\Models\AhuModel;
use App\Models\PpojModel;
use App\Models\SuhuModel;
use App\Models\FlowModel;
use App\Models\PatogenModel;
use App\Models\FileModel;

class Patogen extends BaseController
{
    
    public function index()
    {
        $PpojModel = new PpojModel();
        $SuhuModel = New SuhuModel;
        $AhuModel = New AhuModel;
        $AllModel = new AllModel();
        $FlowModel = new FlowModel();
        $data = [
            
           'List_PPOJ' => $PpojModel->findAll(),
           'List_AHU' => $PpojModel->List_SUHU(),
           'List_Suhu' => $SuhuModel->findAll(),
           'List_Ruangan' => $AllModel->List_Ruangan()

        ];
        
        //echo $FlowModel->Pertukaran_Udara(2);
       // echo view('AtRest/flow', $data);
        echo view('AtRest/patogen', $data);
        //return view('AtRest/flow');
    }
    public function ViewDetail($id)
    {
         $PpojModel = New PpojModel;
         $AllModel = new AllModel();
         $PpojModel = new PpojModel();
         $AhuModel = New AhuModel();
         $PatogenModel = New PatogenModel();
         $Detail_AHU = $PpojModel->where('id',$id)->first();
         $data = [
          
            'List_AHU' => $AllModel->List_AHU(),
            'List_Ruangan' => $AllModel->List_Ruangan(),
            'List_PPOJ' => $PpojModel->List_PPOJ_ID($id),
            'Detail_AHU' => $AhuModel->where('id',$id)->first(),
            'PatogenModel' => $PatogenModel
         ];
         
       //  echo $FlowModel->where('id_ppoj',52)->countAllResults();
        echo view('AtRest/patogen_detail', $data);
     
      
    }

    public function AddPatogen($id)
    {
         $PpojModel = New PpojModel;
         $AllModel = new AllModel();
         $PpojModel = new PpojModel();
         $AhuModel = New AhuModel;
           $SuhuModel = new SuhuModel();
           $FlowModel = new FlowModel();
           $PatogenModel = new PatogenModel();
         $Detail_AHU = $PpojModel->where('id',$id)->first();
         $data = [
             // 'judul' => 'Daftar Antrian'
            'List_AHU' => $AllModel->List_AHU(),
            'List_Ruangan' => $AllModel->List_Ruangan(),
            'Data_Flow' => $FlowModel->where('id_ppoj',$id)->findAll(),
            'List_Patogen' => $PatogenModel->where('id_ppoj',$id)->findAll(),
            'Detail_Ruangan' => $PpojModel->where('id',$id)->first(),
            'List_PPOJ' => $PpojModel->findAll(),
 
         ];
      
    // dd($data);
        return view('AtRest/patogen_add',$data);
   
      
    }
    public function Insert()
    {
        $session = session();
        $PpojModel = New PpojModel;
        $SuhuModel = New SuhuModel;
        $AllModel = new AllModel();
        $FlowModel = new FlowModel();
         $PatogenModel = new PatogenModel();
        $FileModel = new FileModel();
        date_default_timezone_set('Asia/Jakarta');
        // $AllModel = new AllModel();
        $getpost = $this->request->getPost();
       //$suhu[] =      $this->request->getVar('smin');//$getpost['smin[]'];
        
        // foreach($nf as $no => $row ){
          
        //     $batch_data[]=
        //     [
        //         'no_ppoj' => $getpost['ppoj'],
        //         'id_ppoj' => $getpost['id_ppoj'],
        //         'nama_ruangan' => $getpost['ruangan'],
        //         'hasil_flow' => $getpost['nf'][$no],
        //         'volume_ruangan' => $getpost['volume_ruangan'],
        //         'analis' =>$session->get('username'),
        //         'tanggal_dilakukan' => date('Y-m-d H:i:')
        //         //'tanggal_dilakukan' => $getpost['tanggal_dilakukan']
        //     ];

        // }
        // //dd($batch_data);
        // $FlowModel->insertBatch($batch_data);
        $PatogenModel = new PatogenModel();
		// $dataBerkas = $this->request->getFile('file');
		// $fileName = $dataBerkas->getName();
		$PatogenModel->insert([
			// 'hasil_patogen' => $fileName,
            'no_ppoj' => $getpost['ppoj'],
            'id_ppoj' => $getpost['id_ppoj'],
            'nama_ruangan' => $getpost['ruangan'],
            'e_coli'=>$getpost['ecoli'],
            'salmonella_sp'=>$getpost['salmonela'],
            'staphylococcus_aureus'=>$getpost['staphylococcus'],
            'pseudomonas_aeruginosa'=>$getpost['pseudomonas'],
            'shigella_sp'=>$getpost['shigella'],
            'enterobacteriaceae'=>$getpost['enterobacteria'],
            'clostridia_sporogens'=>$getpost['clostridia'],           
            'analis' =>$session->get('username'),
            'keterangan' => $getpost['keterangan'],
            'tanggal_dilakukan' => date('Y-m-d H:i:')
                    //'tanggal_dilakukan' => $getpost['tanggal_dilakukan']
		]);
		// $dataBerkas->move('File/', $fileName);
      session()->setFlashdata('Toast', 'Data Berhasil disimpan');
      return redirect()->back()->withInput();
    }    

    public function Delete($id)
    {
        $PatogenModel = New PatogenModel;
    //     $berkas = $PatogenModel->select('hasil_patogen')->where('id',$id)->first();
    //     $fileName =$berkas['hasil_patogen'];
    //    // echo $fileName;
    //      unlink("File/".$fileName."");
         
    
         $PatogenModel->where('id', $id)->delete();

        session()->setFlashdata('Toast', 'Data Berhasil dihapus');
        return redirect()->back()->withInput();
    }
}
