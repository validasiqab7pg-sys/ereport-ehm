<?php

namespace App\Controllers;
use App\Models\AllModel;
use App\Models\AhuModel;
use App\Models\FlowModel;
use App\Models\PpojModel;
use App\Models\CaparModel;
use App\Models\MasModel;
use App\Models\SuhuModel;
use App\Models\RhModel;
use App\Models\PartikelModel;
use Dompdf\Dompdf;
class DataPpoj extends BaseController
{
    public function index()
    {
        $AllModel = new AllModel();
        $PpojModel = new PpojModel();
        $AhuModel = New AhuModel;
        $data = [
            // 'judul' => 'Daftar Antrian'
           'List_AHU' => $AllModel->List_AHU(),
           'List_Ruangan' => $AllModel->List_Ruangan(),
           'List_PPOJ' => $AhuModel->findAll()

        ];
       // dd($AllModel->selectData("master_data"));
        echo view('AtRest/datappoj', $data);
    //1dd($data);
    }

    public function DetailPpoj($id)
    { 
      $dompdf = new Dompdf(['isRemoteEnabled' => true]);
      $PpojModel = new PpojModel();
      $FlowModel = New FlowModel;
      $SuhuModel = New SuhuModel;
      $AhuModel = New AhuModel;
      $RhModel = New RhModel;
      $PartikelModel = New PartikelModel;
      $CaparModel = New CaparModel;
      $MasModel = New MasModel;
      $countsuhu = count($SuhuModel->where('id_ppoj',$id)->findAll());
      $countrh = count($RhModel->where('id_ppoj',$id)->findAll());
      $countcapar = count($CaparModel->where('id_ppoj',$id)->findAll());
      $countmas = count($MasModel->where('id_ppoj',$id)->findAll());
      $id_ahu = $PpojModel->select('id_ahu')->where('id',$id)->first();
      $kondisi = $AhuModel->select('kondisi')->where('id',$id_ahu)->first();
      $cekpartikel = $PartikelModel->select('*')->where('id_ppoj',$id)->countAllResults();
      $data = [
          'Detail_AHU' => $AhuModel->where('id',$id_ahu)->first(),
          'imageSrc'    => $this->imageToBase64(ROOTPATH . 'public/logob7.png'),
          'Detail_PPOJ' => $PpojModel->where('id',$id)->first(),
          'Detail_Flow' => $FlowModel->where('id_ppoj',$id)->findAll(),
          'DataSuhuRH'  => $PpojModel->DataPDF($countsuhu,$countrh,$countcapar,$countmas,$id),
          'JumlahData' => count($PpojModel->DataPDF($countsuhu,$countrh,$countcapar,$countmas,$id)),
          'Perbedaan_ruangan' =>$PpojModel->Terhadap_Ruangan($id),
          'kondisi' =>$kondisi['kondisi'],
          'cekpartikel' =>$cekpartikel
          
      ];
     
   //  echo $cekpartikel;
    //dd($data);
       $html = view('AtRest/Getpdf2', $data);

   
      $dompdf->loadHtml($html);
      $dompdf->setPaper('A4', 'landscape');
      $dompdf->render();
      $dompdf->stream('Pemantauan_Ruangan.pdf', [ 'Attachment' => true ]);
    }
    private function imageToBase64($path) {
      $path = $path;
      $type = pathinfo($path, PATHINFO_EXTENSION);
      $data = file_get_contents($path);
      $base64 = 'data:image/' . $type . ';base64,' . base64_encode($data);
      return $base64;
  }
    public function Detail($id)
    {
        $AllModel = new AllModel();
      $dompdf = new Dompdf(['isRemoteEnabled' => true]);
      $PpojModel = new PpojModel();
      $FlowModel = New FlowModel;
      $SuhuModel = New SuhuModel;
      $AhuModel = New AhuModel;
      $RhModel = New RhModel;
      $PartikelModel = New PartikelModel;
      $CaparModel = New CaparModel;
      $MasModel = New MasModel;
      $countsuhu = count($SuhuModel->where('id_ppoj',$id)->findAll());
      $countrh = count($RhModel->where('id_ppoj',$id)->findAll());
      $countcapar = count($CaparModel->where('id_ppoj',$id)->findAll());
      $countmas = count($MasModel->where('id_ppoj',$id)->findAll());
      $id_ahu = $PpojModel->select('id_ahu')->where('id',$id)->first();
      $kondisi = $AhuModel->select('kondisi')->where('id',$id_ahu)->first();
      $cekpartikel = $PartikelModel->select('*')->where('id_ppoj',$id)->countAllResults();
      $data = [
          'Detail_AHU' => $AhuModel->where('id',$id_ahu)->first(),
          'List_AHU' => $AllModel->List_AHU(),
           'List_Ruangan' => $AllModel->List_Ruangan(),
           'id' => $id,
           'List_PPOJ' => $AhuModel->findAll(),
          'imageSrc'    => $this->imageToBase64(ROOTPATH . 'public/logob7.png'),
          'Detail_PPOJ' => $PpojModel->where('id',$id)->first(),
          'Detail_Flow' => $FlowModel->where('id_ppoj',$id)->findAll(),
          'DataSuhuRH'  => $PpojModel->DataPDF($countsuhu,$countrh,$countcapar,$countmas,$id),
          'JumlahData' => count($PpojModel->DataPDF($countsuhu,$countrh,$countcapar,$countmas,$id)),
          'Perbedaan_ruangan' =>$PpojModel->Terhadap_Ruangan($id),
          'kondisi' =>$kondisi['kondisi'],
          'cekpartikel' =>$cekpartikel
          
      ];
   
//dd($data);
        //echo $countsuhu.''.$countrh.''.$countcapar.''.$countmas.''.$id;
       // dd($AllModel->selectData("master_data"));
    echo view('AtRest/table', $data);
    //1dd($data);
    }

    public function Insert_AHU()
    {
        $session = session();
        $PpojModel = New PpojModel;
        $AhuModel = New AhuModel;
        $AllModel = new AllModel();
        $getpost = $this->request->getPost();
       
        //$originalDate = $getpost['tanggaldilakukan'];
        date_default_timezone_set('Asia/Jakarta');
        $newDate = date("Y-m-d H:i:s");
        // $newDate1 =date("Y-m-d");
        // $GetKelas = $AllModel->Pilih_Kelas($getpost['ahu'],$getpost['ruangan']);
        //$GetTanggal = $AllModel->Pilih_Tanggal($getpost['tanggaldilakukan']);
       
      //  echo $newDate;
        $AhuModel->insert([ 
            'ahu' => $getpost['ahu'],
            'site' => $getpost['site'],
            'tanggaldilakukan' =>  $newDate,
            'kondisi' => $getpost['kondisi'],
            'jenispemeriksaan' =>$getpost['jenispemeriksaan'],
            'status' => 'On Progress'
            
           
        ]);
       
      session()->setFlashdata('Toast', 'Data Berhasil disimpan');
      return redirect()->to('/DataPpoj');
    }

    public function Insert_PPOJ()
    {
        $session = session();
        $PpojModel = New PpojModel;
        $AllModel = new AllModel();
        $getpost = $this->request->getPost();
       
        //$originalDate = $getpost['tanggaldilakukan'];
        date_default_timezone_set('Asia/Jakarta');
        $newDate = date("Y-m-d H:i:s");
        $newDate1 =date("Y-m-d");
        $GetKelas = $AllModel->Pilih_Kelas($getpost['ahu'],$getpost['ruangan']);
        //$GetTanggal = $AllModel->Pilih_Tanggal($getpost['tanggaldilakukan']);
       
      //  echo $newDate;
        $PpojModel->insert([ 
            'no_ppoj' => "AHU ".$getpost['ahu']."/".$getpost['site']."/".$getpost['ruangan'],//.$getpost['tanggaldilakukan'],
            'ahu' => $getpost['ahu'],
            'id_ahu' => $getpost['id_ahu'],
            'site' => $getpost['site'],
            'nama_ruangan' => $getpost['ruangan'],
             'kelas' =>  $GetKelas->kelas,
           
            'tanggaldilakukan' =>  $getpost['tanggaldilakukan'],
            'jenispemeriksaan' =>$getpost['jenispemeriksaan'],
            'status' => 'On Progress'
            
           
        ]);
       
      session()->setFlashdata('Toast', 'Data Berhasil disimpan');
      return redirect()->back()->withInput();
    }
    public function Ambil_Ahu()
    {
        $AllModel = new AllModel();
        $NamaAhu = $this->request->getPost("nama_ahu");
        $GetAhu = $AllModel->Pilih_Ahu($NamaAhu);
        //selectData("master_data", array("nama_ahu" => $NamaAhu));
      
        echo json_encode($GetAhu); // kirim data ke ajax yang ada di datappoj
    }

  public function Approve_1()
    {
        $session = session();
        $AhuModel = New AhuModel;
         $getpost = $this->request->getPost();
     
        $id = $getpost['id_ahu'];
        $AhuModel->update($id, [
            
                'approve_1' => $session->get('username')
                
        ]);
        
          session()->setFlashdata('Approve', 'Data Berhasil di Approve');
      return redirect()->back()->withInput();
    }

 public function Approve_2()
    {
        $session = session();
        $AhuModel = New AhuModel;
         $getpost = $this->request->getPost();
     
        $id = $getpost['id_ahu'];
        $AhuModel->update($id, [
            
                'approve_2' => $session->get('username')
                
        ]);
        
          session()->setFlashdata('Approve', 'Data Berhasil di Approve');
      return redirect()->back()->withInput();
    }

 public function Approve_3()
    {
        $session = session();
        $AhuModel = New AhuModel;
         $getpost = $this->request->getPost();
     
        $id = $getpost['id_ahu'];
        $AhuModel->update($id, [
            
                'approve_3' => $session->get('username')
                
        ]);
        
          session()->setFlashdata('Approve', 'Data Berhasil di Approve');
      return redirect()->back()->withInput();
    }

     public function Approve_4()
    {
        $session = session();
        $AhuModel = New AhuModel;
         $getpost = $this->request->getPost();
     
        $id = $getpost['id_ahu'];
        $AhuModel->update($id, [
            
                'approve_4' => $session->get('username')
                
        ]);
        
          session()->setFlashdata('Approve', 'Data Berhasil di Approve');
      return redirect()->back()->withInput();
    }

    public function DeleteRuangan($id)
    {
        $PpojModel = New PpojModel;
        $PpojModel->where('id', $id)->delete();

        session()->setFlashdata('Toast', 'Data Berhasil dihapus');
        return redirect()->back()->withInput();
    }

    public function Delete($id)
    {
        $AhuModel = New AhuModel();
        $AhuModel->where('id', $id)->delete();

        session()->setFlashdata('Toast', 'Data Berhasil dihapus');
         return redirect()->to('/DataPpoj');
    }

    
    public function ViewDetail($id)
    {
         $PpojModel = New PpojModel;
         $AllModel = new AllModel();
         $PpojModel = new PpojModel();
         $AhuModel = New AhuModel;
         $Detail_AHU = $PpojModel->where('id',$id)->first();
         $data = [
             // 'judul' => 'Daftar Antrian'
            'List_AHU' => $AllModel->List_AHU(),
            'List_Ruangan' => $AllModel->List_Ruangan(),
            'List_PPOJ' => $PpojModel->List_PPOJ_ID($id),
            'Detail_AHU' => $AhuModel->where('id',$id)->first()
 
         ];
    // dd( $PpojModel->first($id));
        //dd($PpojModel->List_PPOJ_ID($Detail_AHU['ahu'],$Detail_AHU['tanggaldilakukan']));
        echo view('AtRest/datappoj_detail', $data);
      //dd($Detail_AHU);
      
    }
    
}
