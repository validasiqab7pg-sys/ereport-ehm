<?php echo view('parsial/navbar'); ?>
<?php echo view('parsial/sidebar'); ?>
<div class="main-content">
    <?php $session = session(); ?>
    <div class="page-content">
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-flex align-items-center justify-content-between">
                        <h4 class="mb-0">Suhu</h4>

                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <!-- <li class="breadcrumb-item"><a href="javascript: void(0);">D</a></li> -->
                                <li class="breadcrumb-item active">Data Suhu</li>
                            </ol>
                            <!-- end ol -->
                        </div>
                    </div>
                </div>
                <!-- end col -->
            </div>

            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-body">
                        


                            <!-- end dropdown -->
                            <h4 class="card-title mb-4">Data Suhu</h4>
                            <div class="card-body table-responsive">
                      
                        <div class="">
                            <table  border="1">
                             
                                    <tr>
                                        <th rowspan="7">Titik Sampling</th>
                                        <th rowspan="2">Kelas</th>
                                        <th colspan="2">Suhu</th>
                                        <th colspan="2">RH</th>
                                        <th rowspan="2">Perbedaan Tekanan Ruangan (Pal)</th>
                                        <th rowspan="7">Flow CFM</th>
                                        <th rowspan="2">Jumlah Pertukaran Udara</th>
                                        <th rowspan="1" colspan="4">Jumlah Partikel Maks</th>
                                        <th colspan="2" rowspan="1">Mikroba Volumetrik</th>
                                        <th colspan="2" rowspan="1">Mikroba Cawan Papar</th>
                                        <th rowspan="7">Kesimpulan</th>
                                        
                                    </tr>
                            
                                        <tr>
                                            <td>Min</td>
                                            <td>Max</td>
                                            <td>Min</td>
                                            <td>Max</td>
                                            <td colspan="2" rowspan="1">AtRest</td>
                                            <td colspan="2">In Operation</td>
                                            <td>TPC</td>
                                            <td>KK</td>
                                            <td>TPC</td>
                                            <td>KK</td>
                                            
                                            
                                           
                                        </tr>
                                        <tr>
                                            <td>A</td>
                                            <td>16</td>
                                            <td>22</td>
                                            <td>45</td>
                                            <td>55</td>
                                            <td rowspan="5">5A</td>
                                            <td>Min 500</td>
                                            <td>0.5</td>
                                            <td>5.1</td>
                                            <td>0.5</td>
                                            <td>5.1</td>
                                            <td>BA</td>
                                            <td>BB</td>
                                            <td>BC</td>
                                            <td>BD</td>
                                        </tr>
                                        <tr>
                                            <td>C</td>
                                            <td>16</td>
                                            <td>22</td>
                                            <td>45</td>
                                            <td>55</td>
                                            <td>Min 20</td>
                                            <td>3520</td>
                                            <td>20</td>
                                            <td>3520</td>
                                            <td>20</td>
                                            <td>< 1</td>
                                            <td>< 1</td>
                                            <td>< 1</td>
                                            <td>< 1</td>
                                        </tr>
                                        <tr>
                                            <td>D</td>
                                            <td>20</td>
                                            <td>27</td>
                                            <td>40</td>
                                            <td>60</td>
                                            <td>Min 20</td>
                                            <td>6D</td>
                                            <td>7D</td>
                                            <td>8D</td>
                                            <td>9D</td>
                                            <td>DA</td>
                                            <td>DB</td>
                                            <td>DC</td>
                                            <td>DD</td>
                                        </tr>
                                     
                                        <tr>
                                            <td>E</td>
                                            <td>20</td>
                                            <td>27</td>
                                            <td colspan="2"><= 70</td>
                                            <td>5 - 20 atau >=20</td>
                                            <td>5E</td>
                                            <td>6E</td>
                                            <td>7E</td>
                                            <td>8E</td>
                                            <td>EA</td>
                                            <td>EB</td>
                                            <td>EC</td>
                                            <td>ED</td>
                                        </tr>
                                        <tr>
                                            <td>E Khusus</td>
                                            <td>16</td>
                                            <td>25</td>
                                            <td colspan="2"><=30</td>
                                            <td>5 - 20 atau >=20</td>
                                            <td>5EK</td>
                                            <td>6EK</td>
                                            <td>7EK</td>
                                            <td>8EK</td>
                                            <td>9EK</td>
                                            <td>86</td>
                                            <td>76</td>
                                            <td>86</td>
                                            
                                        </tr>
                                       
                                        
                               
                            </table>
                        </div>
                    </div>
                            <!-- end tableresponsive -->
                        </div>
                    </div>
                </div>
                <!-- end col -->
            </div>
            <!-- end row -->
        </div>
        <!-- end container-fluid -->
    </div>
    <!-- End Page-content -->
</div>
<!-- end main content-->
</div>
<!-- END layout-wrapper -->
<?php echo view('parsial/footer'); ?>