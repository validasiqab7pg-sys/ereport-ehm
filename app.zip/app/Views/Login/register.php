<!doctype html>
<html lang="en">

<head>

    <meta charset="utf-8" />
    <title>E Report Kualifikasi EHM</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="Themesdesign" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="assets/images/b7.png">

    <!-- Bootstrap Css -->
    <link href="assets/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
    <!-- Icons Css -->
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <!-- App Css-->
    <link href="assets/css/app.min.css" id="app-style" rel="stylesheet" type="text/css" />

</head>

<body class="auth-body-bg">
    <div class="home-btn d-none d-sm-block">
        <a href="index.html"></a>
    </div>
    <div class="account-pages my-5 pt-5">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8 col-lg-6 col-xl-5">
                    <div class="card">
                        <div class="card-body">
                            <div class="text-center mt-4">
                                <div class="mb-3">
                                    <a href="index.html" class="">
                                        <img src="assets/images/logo-b7.png" alt="" height="75" class="auth-logo logo-dark mx-auto">
                                       
                                    </a>
                                </div>
                            </div>
                            <div class="p-3">
                                <h4 class="font-size-18 text-muted mt-2 text-center">Register</h4>
                                <p class="text-muted text-center mb-4">Get your e-report account now.</p>

                                <form class="form-horizontal" action="<?=base_url()?>Register/Process" method="post">

                                    <div class="mb-3">
                                        <label class="form-label" for="useremail">Email</label>
                                        <input type="email" class="form-control" id="useremail" name="email"
                                            placeholder="Enter email">
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label" for="username">Username</label>
                                        <input type="text" class="form-control" id="username" name="username"
                                            placeholder="Enter username"> 
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label" for="userpassword">Password</label>
                                        <input type="password" class="form-control" id="userpassword" name="password"
                                            placeholder="Enter password">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label" for="departemen">Department</label>
                                        <input type="text" class="form-control" id="userdept" name="department"
                                            placeholder="Enter Department">
                                    </div>
                                  
                                        <div class="mb-3">
                                            <label for="validationCustom03" class="form-label">Position</label>
                                            <select class="form-control" id="validationCustom03" name="jabatan" required>
                                                <option selected disabled value="">Choose...</option>
                                                <option value="QA Analis">QA Analis</option>
                                                <option value="QC Analis">QC Analis</option>
                                                <option value="Spv QA">Spv QA</option>
                                                <option value="Spv QC">Spv QC</option>
                                                <option value="Manager QA">Manager QA</option>
                                                <option value="Manager QC">Manager QC</option>
                                            </select>
                                        </div>


                                    <div class="mb-3 row mt-4">
                                        <div class="col-12 text-end">
                                            <button class="btn btn-primary w-100 waves-effect waves-light"
                                                type="submit">Register</button>
                                        </div>
                                    </div>



                                  

                                   
                                    <!-- end row -->
                                </form>

                            </div>

                        </div>
                    </div>
                    <div class="mt-5 text-center">
                        <p>Already have an account ? <a href="<?= base_url() ?>Login" class="fw-bold text-primary"> Login </a>
                        </p>
                        <p>
                            <script>document.write(new Date().getFullYear())</script> © Digitalization Crafted with <i
                                class="mdi mdi-heart text-danger"></i> by Digitalization
                        </p>
                    </div>

                </div>
            </div>
        </div>
    </div>



    <!-- JAVASCRIPT -->
    <script src="assets/libs/jquery/jquery.min.js"></script>
    <script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/libs/metismenu/metisMenu.min.js"></script>
    <script src="assets/libs/simplebar/simplebar.min.js"></script>
    <script src="assets/libs/node-waves/waves.min.js"></script>

    <script src="assets/js/app.js"></script>

</body>

</html>