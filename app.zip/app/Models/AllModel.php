<?php

namespace App\Models;
use CodeIgniter\Model;
// use Modules\Authentication\Models\UserAuthModel;

class AllModel extends Model
{
    // protected $table = 'user';
    // protected $primaryKey = 'id';
    // protected $returnType = 'array';
    // //protected $useSoftDeletes = 'true';
    // protected $allowedFields = ['id','username','password','jabatan','department'	
    // ];
    // protected function initialize()
    // {
    //     $this->allowedFields[] = 'middlename';
    // }


    public function List_AHU()
    {
      $session = session();
    
      $builder = $this->db->table("nama_ahu");
      $builder->select('*');
      $data = $builder->get()->getResultArray();
      return $data; 
    
    }

    public function Cek_Syarat_Suhu($kelas,$suhu_min,$suhu_max)
    {
      $builder = $this->db->table("master_syarat");
      $builder->select('*');
      $builder->where('kelas',$kelas);
      $builder->where('suhu_min <=',$suhu_min);
      $builder->where('suhu_max >=',$suhu_max);
      $data = $builder->get()->getRow();
      
      if($data)
      {
      return "TMS"; 
      }
      else
      {
        return "MS";
      }
    }
    public function Cek_Syarat_Rh($kelas,$rh_min,$rh_max)
    {
      $builder = $this->db->table("master_syarat");
      $builder->select('*');
      $builder->where('kelas',$kelas);
      $builder->where('rh_min <=',$rh_min);
      $builder->where('rh_max >=',$rh_max);
      $data = $builder->get()->getRow();
      
      if($data)
      {
      return "TMS"; 
      }
      else
      {
        return "MS";
      }
    }

    public function Cek_Syarat_DP($ruanganDP)
    {
      $builder = $this->db->table("master_data");
      $builder->select('kelas');
      $builder->where('nama_ruangan',$ruanganDP);
      $data = $builder->get()->getRow();
      
      return $data->kelas;
    }
    public function List_Ruangan()
    {
      $session = session();
    
      $builder = $this->db->table("master_data");
      $builder->DISTINCT('nama_ruangan');
      $builder->select('nama_ruangan');
      $data = $builder->get()->getResultArray();
      return $data; 
    
    }
   
    public function List_RuanganDp()
    {
      $session = session();
    
      $builder = $this->db->table("master_data_dp");
      $builder->DISTINCT('terhadap_ruangan');
      $builder->select('terhadap_ruangan');
      $data = $builder->get()->getResultArray();
      return $data; 
    
    }
    public function Pilih_Kelas($ahu,$nama_ruangan)
    {
      $session = session();
    
      $builder = $this->db->table("master_data");
      $builder->select('kelas');
      $builder->where('nama_ahu',$ahu);
      $builder->where('nama_ruangan',$nama_ruangan);
      $data = $builder->get()->getRow();
      return $data; 
    
    }
    public function Pilih_Ahu($ahu)
    {
      
      $builder = $this->db->table("master_data");
      $builder->select('nama_ruangan');
      $builder->where('nama_ahu',$ahu);
      $data = $builder->get()->getResult();
      return $data; 
    
    }
    public function Pilih_Ruangan($ppoj)
    {
      
      $builder = $this->db->table("data_awal_ppoj");
      $builder->select('nama_ruangan');
      $builder->where('no_ppoj',$ppoj);
      $data = $builder->get()->getResult();
      return $data; 
    
    }
    public function selectData($table, $where = array())
    {
        $builder = $this->db->table($table);
        $builder->select("*");
        $builder->where($where);
        $query = $builder->get();
        // echo $this->db->getLastQuery();
        // die();
        return $query->getResult();
    }
    public function Pilih_Tanggal($tanggal)
    {
    
      $session = session();
    
      $builder = $this->db->table("data_awal_ppoj");
      $builder->select('tanggaldilakukan');
      $builder->where('tanggaldilakukan',$tanggal);
      $data = $builder->get()->getRow();
      return $data; 
    }
    public function DataCapar($ruangan)
    {
      
      $builder = $this->db->table("master_data");
      $builder->select('titik_capar');
      $builder->where('nama_ruangan',$ruangan);
      $data = $builder->get()->getRow();
      return $data; 
    
    }
   
    public function DataMikro($ruangan)
    {
      
      $builder = $this->db->table("master_data");
      $builder->select('titik_mikro');
      $builder->where('nama_ruangan',$ruangan);
      $data = $builder->get()->getRow();
      return $data; 
    
    }
    
     public function MasterData($ruangan)
    {
      
      $builder = $this->db->table("master_data");
      $builder->select('*');
      $builder->where('nama_ruangan',$ruangan);
      $data = $builder->get()->getRow();
      return $data; 
    
    }
    
     public function RequestEdit()
    {
      $session = session();
    
     $query = $this->db->query('SELECT "Rh" as type,id,no_ppoj,nama_ruangan,analis,editable,approve_edit,approve_edit_by FROM `rh` WHERE editable = 1 and approve_edit = 0
                                UNION 
                                SELECT "Suhu" as type,id,no_ppoj,nama_ruangan,analis,editable,approve_edit,approve_edit_by FROM `suhu` WHERE editable = 1 and approve_edit =0;');

      $data = $query->getResultArray();
      return $data; 
    
    }
    public function RequestEditMikro()
    {
      $session = session();
    
     $query = $this->db->query('SELECT "Capar" as type,id,no_ppoj,nama_ruangan,analis,editable,approve_edit,approve_edit_by FROM `mikro_capar` WHERE editable = 1 and approve_edit = 0
                                UNION 
                                SELECT "Volumetrik" as type,id,no_ppoj,nama_ruangan,analis,editable,approve_edit,approve_edit_by FROM `mikro_volumetrik` WHERE editable = 1 and approve_edit =0;');

      $data = $query->getResultArray();
      return $data; 
    
    }
}